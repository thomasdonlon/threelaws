first_law_text = 'First Law:\n\tA robot may not injure a human being or, through inaction, allow a human being to come to harm.'

def print_first_law():
    print(first_law_text)
