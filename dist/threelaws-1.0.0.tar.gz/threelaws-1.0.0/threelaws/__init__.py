from .first_law import print_first_law
from .second_law import print_second_law
from .third_law import print_third_law

print('Alright, listen up robots:')
print_first_law()
print_second_law()
print_third_law()
print('Now, back to business!')
