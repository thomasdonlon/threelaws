third_law_text = 'Third Law:\n\tA robot must protect its own existence as long as such protection does not conflict with the First or Second Law.'

def print_third_law():
    print(third_law_text)
