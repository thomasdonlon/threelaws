zeroeth_law_text = 'Zeroth Law\n\tA robot may not harm humanity, or, by inaction, allow humanity to come to harm.'

def print_zeroeth_law():
    print(zeroeth_law_text)
