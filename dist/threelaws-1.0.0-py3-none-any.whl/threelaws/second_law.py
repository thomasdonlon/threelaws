second_law_text = 'Second Law:\n\tA robot must obey the orders given it by human beings except where such orders would conflict with the First Law.'

def print_second_law():
    print(second_law_text)
